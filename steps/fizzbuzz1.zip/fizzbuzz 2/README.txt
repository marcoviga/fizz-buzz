FizzBuzz application

To run the program you need to:
create the package: mvn package
run the jar contained in target: java -jar target/fizzbuzz-1.0-SNAPSHOT-jar-with-dependencies.jar 1 20